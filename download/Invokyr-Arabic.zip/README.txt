Invokyr — Arabic translation — version 1.0.1
Translation: Abdullah Hadi (عبدالله هادي)
Made for the Steam build 26412219

=============================================
     Install (two minutes)
=============================================

1) Close the game completely.
2) In Steam: right-click Invokyr > Manage > Browse local files
   (opens the game folder that holds Invokyr.exe).
3) Backup (recommended): copy these original files somewhere outside the game folder:
     Invokyr_Data\resources.assets
     Invokyr_Data\StreamingAssets\aa\catalog.bin
     Invokyr_Data\StreamingAssets\aa\StandaloneWindows64\60651c2dbc10ef905bab93590ff7ac6b.bundle
     Invokyr_Data\StreamingAssets\aa\StandaloneWindows64\f7c3a4f755e388f7fbe04aec1e799710.bundle
     Invokyr_Data\StreamingAssets\aa\StandaloneWindows64\8bd48d25285f4b485e6e335fd9e4b66c.bundle
     Invokyr_Data\StreamingAssets\aa\StandaloneWindows64\354a93003dfa0b2c41f2c0db63c621c4.bundle
4) Drag the Invokyr_Data folder from the zip into the game folder and choose
   "Replace the files in the destination".
5) Start the game: Options > Gameplay > Language > «العربية».

The files must REPLACE the originals with exactly the same names; a file saved next to them under another
name is ignored by the game.

=============================================
     Notes
=============================================

- Voices stay in English; all text is Arabic.
- To end the game you must shout the game's name into the microphone: say it in English, "Invokyr"
  (the game recognises the English word).
- Online co-op works as usual: each player sees the language chosen on their own PC, so you can play with
  friends who play in English. Install the translation on every PC that wants Arabic.
- The translator's name is shown on the main-menu Quit button.

=============================================
     After a game update
=============================================

- An update may replace some files and the text goes back to English.
- Do NOT copy this version onto a newer game version: these files are made for build 26412219 and mixing them
  with newer update files can break the game.
- After an update: Steam > Properties > Installed Files > Verify integrity of game files, then wait for an
  updated release of the translation.

=============================================
     Back to English
=============================================

- Put back the original files you saved in step 3, or
- Steam > Properties > Installed Files > Verify integrity of game files.

=============================================
     Credits
=============================================

- Unofficial fan translation by Abdullah Hadi, not affiliated with the game's developers. The game and its
  files belong to their owners; you need your own copy of the game on Steam.
- Arabic font: Almarai, licensed under the SIL Open Font License 1.1.

=============================================
     Almarai font licence (SIL OFL 1.1)
=============================================

Copyright 2019 The Almarai Project Authors (https://github.com/JuergenWillrodt/Almarai)

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
http://scripts.sil.org/OFL


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded, 
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
